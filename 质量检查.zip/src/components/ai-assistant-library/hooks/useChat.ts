import { ref, reactive, computed, watch, effectScope, onUnmounted } from 'vue'
import { v4 as uuidv4 } from 'uuid'
import { ElMessage } from 'element-plus'
import { streamMessage, uploadAttachment } from '@/api/chat'
import type { Message, MessageRole, MessageStatus, Attachment, AIModel, ChatConfig, ChatContext, Reference, RAGChatRequest, NormalChatRequest, DocumentAggregation } from '@/types/chat'
import { useAIModels } from './useAIModels'
import {
  streamNormalChat,
  streamRAGChat,
  normalChat,
  ragChat
} from '@/api/chat'

/**
 * 聊天功能的核心逻辑封装
 */
export function useChat(initialConfig: ChatConfig = {
  modelId: '',
  deepthinking: false,
  rag: false,
  knowledgeBaseId: null,
  fullTextReference: false
}) {
  const scope = effectScope()
  
  // 消息列表状态
  const messages = ref<Message[]>([])
  
  // 集成 AI 模型管理，确保在同一个作用域内
  const aiModelsResult = scope.run(() => useAIModels())
  const { currentModelId, currentModel, selectModel: selectAIModel } = aiModelsResult || { 
    currentModelId: ref(''), 
    currentModel: computed(() => undefined), 
    selectModel: () => {} 
  }
  
  // 深度思考模式
  const isDeepThinkingMode = ref<boolean>(initialConfig.deepthinking || false)
  
  // RAG模式（检索增强生成）
  const isRAGMode = ref<boolean>(initialConfig.rag || false)
  
  // 全文引用模式
  const isFullTextReferenceMode = ref<boolean>(initialConfig.fullTextReference || false)
  
  // 当前使用的知识库ID
  const currentKnowledgeBaseId = ref<string | null>(initialConfig.knowledgeBaseId || null)
  
  // 是否正在生成回复
  const isGenerating = ref<boolean>(false)
  
  // 中止控制器，用于取消请求
  const abortController = ref<AbortController | null>(null)
  
  // 计算属性：最后一条消息
  const lastMessage = computed<Message | undefined>(() => {
    if (messages.value.length === 0) return undefined
    return messages.value[messages.value.length - 1]
  })
  
  // 计算属性：是否有消息
  const hasMessages = computed<boolean>(() => messages.value.length > 0)
  
  // 配置对象
  const config = ref<ChatConfig>({
    ...initialConfig,
    modelId: currentModelId.value || initialConfig.modelId,
    deepthinking: isDeepThinkingMode.value,
    rag: isRAGMode.value,
    knowledgeBaseId: currentKnowledgeBaseId.value,
    fullTextReference: isFullTextReferenceMode.value
  })
  const currentReferences = ref<Reference[]>([])
  
  // 计算属性：当前会话ID
  const sessionId = computed(() => {
    return uuidv4();
  });

  // 计算属性：当前聊天ID
  const chatId = computed(() => {
    return uuidv4();
  });
  
  /**
   * 创建新消息对象
   */
  function createMessage(role: MessageRole, content: string, attachments?: Attachment[]): Message {
    return {
      id: uuidv4(),
      role,
      content,
      timestamp: Date.now(),
      status: role === 'user' ? 'completed' : 'generating',
      attachments
    }
  }
  
  /**
   * 添加消息到列表
   */
  function addMessage(message: Partial<Message>): Message {
    const newMessage: Message = {
      id: message.id || uuidv4(),
      role: message.role || 'user',
      content: message.content || '',
      timestamp: message.timestamp || Date.now(),
      status: message.status || 'completed',
      thinking: message.thinking,
      commandId: message.commandId,
      reference: message.reference,
      docAggs: message.docAggs,
      modelInfo: message.modelInfo // 添加模型信息
    };
    messages.value.push(newMessage);
    return newMessage;
  }
  
  /**
   * 更新消息状态
   */
  function updateMessageStatus(messageId: string, status: MessageStatus): void {
    const message = messages.value.find(msg => msg.id === messageId)
    if (message) {
      message.status = status
    }
  }
  
  /**
   * 更新消息内容
   */
  function updateMessageContent(messageId: string, content: string): void {
    const message = messages.value.find(msg => msg.id === messageId)
    if (message) {
      message.content = content
    }
  }
  
  /**
   * 发送用户消息并获取AI回复
   */
  async function sendUserMessage(content: string, attachments?: Attachment[], commandId?: string, commandName?: string): Promise<void> {
    if (!content.trim() && (!attachments || attachments.length === 0)) {
      ElMessage.warning('消息不能为空')
      return
    }
    
    // 创建用户消息
    const userMessage = {
      id: uuidv4(),
      role: 'user' as const,
      content,
      timestamp: Date.now(),
      status: 'completed' as const,
      attachments,
      commandId,
      commandName
    } as Message;
    
    // 添加用户消息到列表
    addMessage(userMessage)
    
    // 创建AI回复消息（初始为空）
    const aiMessage = addMessage({
      id: uuidv4(),
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      status: 'thinking',
      modelInfo: currentModel.value
    });
    
    // 设置生成状态
    isGenerating.value = true;
    
    // 创建中止控制器
    abortController.value = new AbortController();
    
    try {
      // 更新AI消息状态为生成中
      updateMessageStatus(aiMessage.id, 'generating');
      
      if (isRAGMode.value && currentKnowledgeBaseId.value) {
        // 使用RAG模式
        const ragRequest: RAGChatRequest = {
          chatId: uuidv4(),
          sessionId: uuidv4(),
          question: content,
          deepthinking: isDeepThinkingMode.value,
          knowledgeBaseId: currentKnowledgeBaseId.value
        };

        await streamRAGChat(
          ragRequest,
          (content: string) => {
            updateMessageContent(aiMessage.id, content);
          },
          (err: Error) => {
            console.error('RAG Chat Error:', err);
            updateMessageStatus(aiMessage.id, 'error');
            aiMessage.error = err.message || '获取AI回复失败';
            ElMessage.error('获取AI回复失败: ' + (err.message || '未知错误'));
          },
          () => {
            updateMessageStatus(aiMessage.id, 'completed');
            isGenerating.value = false;
            abortController.value = null;
          },
          abortController.value
        );
      } else {
        // 使用普通模式
        // 准备请求数据
        const normalRequest: NormalChatRequest = {
          prompt: content,
          modelId: currentModel.value?.id,
          deepthinking: isDeepThinkingMode.value,
          attachments: attachments
        };
        
        // 使用新的流式函数
        await streamNormalChat(
          normalRequest,
          (content: string) => {
            updateMessageContent(aiMessage.id, content);
          },
          (err: Error) => {
            console.error('Normal Chat Error:', err);
            updateMessageStatus(aiMessage.id, 'error');
            aiMessage.error = err.message || '获取AI回复失败';
            ElMessage.error('获取AI回复失败: ' + (err.message || '未知错误'));
          },
          () => {
            updateMessageStatus(aiMessage.id, 'completed');
            isGenerating.value = false;
            abortController.value = null;
          },
          abortController.value,
          (thinking: string) => {
            // 保存思考内容
            aiMessage.thinking = thinking;
            }
        );
      }
    } catch (err: any) {
      // 检查是否是用户取消
      if (err.name === 'AbortError') {
        updateMessageStatus(aiMessage.id, 'stopped');
      } else {
        // 其他错误
        updateMessageStatus(aiMessage.id, 'error');
        aiMessage.error = err.message || '获取AI回复失败';
        ElMessage.error('获取AI回复失败: ' + (err.message || '未知错误'));
      }
    } finally {
      // 重置状态
      isGenerating.value = false;
      abortController.value = null;
    }
  }
  
  /**
   * 停止生成回复
   */
  function stopGeneration(): void {
    if (abortController.value) {
      abortController.value.abort()
      abortController.value = null
    }
    isGenerating.value = false
  }
  
  /**
   * 重新生成回复
   */
  async function regenerateMessage(aiMessageToRegenerate: Message): Promise<void> {
    if (isGenerating.value) return;

    const messageIndex = messages.value.findIndex(msg => msg.id === aiMessageToRegenerate.id);
    
    // 确保找到了AI消息，并且它不是第一条消息（前面必须有用户消息）
    if (messageIndex < 1) return;

    const userMessageToResend = messages.value[messageIndex - 1];

    // 确保前一条消息是用户消息
    if (userMessageToResend.role !== 'user') return;

    // 从当前消息列表中移除这对用户-AI消息以及之后的所有消息
    messages.value.splice(messageIndex - 1);

    // 重新发送原始用户消息
    await sendUserMessage(
      userMessageToResend.content,
      userMessageToResend.attachments,
      userMessageToResend.commandId,
      userMessageToResend.commandName
    );
  }
  
  /**
   * 清空消息列表
   */
  function clearMessages(): void {
    messages.value = []
    currentReferences.value = []
  }
  
  /**
   * 设置消息反馈（点赞/点踩）
   */
  function setMessageFeedback(messageId: string, feedback: 'like' | 'dislike'): void {
    const message = messages.value.find(msg => msg.id === messageId)
    if (message) {
      message.feedback = feedback
    }
  }
  
  /**
   * 上传附件
   */
  async function uploadFile(file: File): Promise<Attachment> {
    try {
      const response = await uploadAttachment(file)
      return {
        id: response.id,
        name: file.name,
        type: file.type,
        size: file.size,
        url: response.url,
        thumbnail: response.thumbnail
      }
    } catch (error: any) {
      ElMessage.error('上传附件失败: ' + (error.message || '未知错误'))
      throw error
    }
  }
  
  /**
   * 更新配置
   */
  function updateConfig(newConfig: Partial<ChatConfig>) {
    config.value = {
      ...config.value,
      ...newConfig
    };
    
    // 同步RAG模式
    if (newConfig.rag !== undefined) {
      isRAGMode.value = newConfig.rag;
    }
    
    // 同步深度思考模式
    if (newConfig.deepthinking !== undefined) {
      isDeepThinkingMode.value = newConfig.deepthinking;
    }
    
    // 同步知识库ID
    if (newConfig.knowledgeBaseId !== undefined) {
      currentKnowledgeBaseId.value = newConfig.knowledgeBaseId;
    }
    
    // 同步全文引用模式
    if (newConfig.fullTextReference !== undefined) {
      isFullTextReferenceMode.value = newConfig.fullTextReference;
    }
  }
  
  /**
   * 切换深度思考模式
   */
  function toggleDeepThinkingMode(): void {
    isDeepThinkingMode.value = !isDeepThinkingMode.value
    // 同步到配置
    config.value.deepthinking = isDeepThinkingMode.value;
  }
  
  /**
   * 切换RAG模式
   */
  function toggleRAGMode(): void {
    isRAGMode.value = !isRAGMode.value
    
    // 同步到配置
    config.value.rag = isRAGMode.value;
    
    // 不再自动清空知识库ID，让用户可以保留选择的知识库
    // if (!isRAGMode.value) {
    //   currentKnowledgeBaseId.value = null
    // }
  }
  
  /**
   * 切换全文引用模式
   */
  function toggleFullTextReferenceMode(): void {
    isFullTextReferenceMode.value = !isFullTextReferenceMode.value
    // 同步到配置
    config.value.fullTextReference = isFullTextReferenceMode.value;
  }
  
  /**
   * 设置当前使用的AI模型
   */
  function setCurrentModel(modelId: string): void {
    selectAIModel(modelId)
    // 同步到配置
    config.value.modelId = modelId;
  }
  
  /**
   * 设置当前使用的知识库
   */
  function setCurrentKnowledgeBase(knowledgeBaseId: string | null): void {
    currentKnowledgeBaseId.value = knowledgeBaseId
    // 同步到配置
    config.value.knowledgeBaseId = knowledgeBaseId;
    
    // 如果设置了知识库，自动开启RAG模式
    if (knowledgeBaseId) {
      isRAGMode.value = true
      config.value.rag = true
    }
    // 当清除知识库ID时，不自动关闭RAG模式，让用户自行决定是否关闭
  }
  
  // 添加用户消息
  function addUserMessage(content: string): Message {
    const message: Message = {
      id: uuidv4(),
      role: 'user' as MessageRole,
      content,
      timestamp: Date.now()
    };
    messages.value.push(message);
    return message;
  }

  // 添加助手消息
  function addAssistantMessage(content: string, thinking?: string): Message {
    const message: Message = {
      id: uuidv4(),
      role: 'assistant' as MessageRole,
      content,
      timestamp: Date.now(),
      status: 'pending' as MessageStatus,
      thinking,
      ...(currentModel.value ? { modelInfo: currentModel.value } : {})
    };
    messages.value.push(message);
    return message;
  }

  // 更新消息内容
  function updateMessage(id: string, content: string) {
    const message = messages.value.find(m => m.id === id);
    if (message) {
      message.content = content;
    }
  }

  // 编辑用户消息
  async function editUserMessage(messageId: string, newContent: string, onCompletedCallback?: () => void): Promise<void> {
    if (isGenerating.value) {
      stopGeneration();
    }

    const messageIndex = messages.value.findIndex(msg => msg.id === messageId);
    if (messageIndex === -1 || messages.value[messageIndex].role !== 'user') {
      ElMessage.error('只能编辑用户消息');
      return;
    }

    const userMessage = messages.value[messageIndex];
    
    // 保存原始内容
    if (!userMessage.originalContent) {
      userMessage.originalContent = userMessage.content;
    }
    
    // 更新消息内容
    userMessage.content = newContent;
    userMessage.edited = true;
    
    // 如果这不是最后一条消息，需要删除之后的所有消息
    if (messageIndex < messages.value.length - 1) {
      // 移除该消息之后的所有消息
      messages.value.splice(messageIndex + 1);
    }
    
    // 将消息状态设置为completed
    updateMessageStatus(messageId, 'completed');
    
    // 创建AI回复消息（初始为空）
    const aiMessage = addMessage({
      id: uuidv4(),
      role: 'assistant',
      content: '',
      timestamp: Date.now(),
      status: 'thinking',
      modelInfo: currentModel.value
    });
    
    // 设置生成状态
    isGenerating.value = true;
    
    // 创建中止控制器
    abortController.value = new AbortController();
    
    try {
      // 更新AI消息状态为生成中
      updateMessageStatus(aiMessage.id, 'generating');
      
      if (isRAGMode.value && currentKnowledgeBaseId.value) {
        // 使用RAG模式
        const ragRequest: RAGChatRequest = {
          chatId: uuidv4(),
          sessionId: uuidv4(),
          question: newContent,
          deepthinking: isDeepThinkingMode.value,
          knowledgeBaseId: currentKnowledgeBaseId.value
        };

        await streamRAGChat(
          ragRequest,
          (content: string) => {
            updateMessageContent(aiMessage.id, content);
          },
          (err: Error) => {
            console.error('RAG Chat Error:', err);
            updateMessageStatus(aiMessage.id, 'error');
            aiMessage.error = err.message || '获取AI回复失败';
            ElMessage.error('获取AI回复失败: ' + (err.message || '未知错误'));
            if (onCompletedCallback) onCompletedCallback();
          },
          () => {
            updateMessageStatus(aiMessage.id, 'completed');
            isGenerating.value = false;
            abortController.value = null;
            if (onCompletedCallback) onCompletedCallback();
          },
          abortController.value
        );
      } else {
        // 使用普通模式
        // 准备请求数据
        const normalRequest: NormalChatRequest = {
          prompt: newContent,
          modelId: currentModel.value?.id,
          deepthinking: isDeepThinkingMode.value,
          attachments: userMessage.attachments
        };

        // 使用新的流式函数
        await streamNormalChat(
          normalRequest,
          (content: string) => {
            updateMessageContent(aiMessage.id, content);
          },
          (err: Error) => {
            console.error('Normal Chat Error:', err);
            updateMessageStatus(aiMessage.id, 'error');
            aiMessage.error = err.message || '获取AI回复失败';
            ElMessage.error('获取AI回复失败: ' + (err.message || '未知错误'));
            if (onCompletedCallback) onCompletedCallback();
          },
          () => {
        updateMessageStatus(aiMessage.id, 'completed');
            isGenerating.value = false;
            abortController.value = null;
        if (onCompletedCallback) onCompletedCallback();
          },
          abortController.value,
          (thinking: string) => {
            // 保存思考内容
            aiMessage.thinking = thinking;
          }
        );
      }
    } catch (err: any) {
      // 检查是否是用户取消
      if (err.name === 'AbortError') {
        updateMessageStatus(aiMessage.id, 'stopped');
      } else {
        // 其他错误
        updateMessageStatus(aiMessage.id, 'error');
        aiMessage.error = err.message || '获取AI回复失败';
        ElMessage.error('获取AI回复失败: ' + (err.message || '未知错误'));
      }
      if (onCompletedCallback) onCompletedCallback();
    } finally {
      // 重置状态
      isGenerating.value = false;
      abortController.value = null;
    }
  }

  // 开始编辑消息
  function startEditingMessage(messageId: string): void {
    const message = messages.value.find(msg => msg.id === messageId);
    if (message && message.role === 'user') {
      updateMessageStatus(messageId, 'editing');
    }
  }

  // 取消编辑消息
  function cancelEditingMessage(messageId: string): void {
    const message = messages.value.find(msg => msg.id === messageId);
    if (message && message.status === 'editing') {
      updateMessageStatus(messageId, 'completed');
    }
  }

  // 清理副作用
  scope.run(() => {
    // 在这里注册需要自动清理的副作用
  });

  // 返回公开的API
  return {
    messages,
    currentModelId,
    currentModel,
    isDeepThinkingMode,
    isRAGMode,
    isFullTextReferenceMode,
    isGenerating,
    hasMessages,
    lastMessage,
    currentKnowledgeBaseId,
    currentReferences,
    sendUserMessage,
    stopGeneration,
    regenerateMessage,
    clearMessages,
    setMessageFeedback,
    uploadFile,
    updateConfig,
    toggleDeepThinkingMode,
    toggleRAGMode,
    toggleFullTextReferenceMode,
    setCurrentModel,
    setCurrentKnowledgeBase,
    addUserMessage,
    addAssistantMessage,
    updateMessage,
    editUserMessage,
    startEditingMessage,
    cancelEditingMessage
  }
} 
